#include"all.hpp"
void containProcCls::print(void)
  {
/*  outDebugError<<" the procedure is++++++++++++++++++++++++++++++++++++++"<<endl;
  outDebugError<<"ncts1 "<< ncts<<" noExpose "<<noExpose<<endl;
  outDebugError<<"name Proc "<< nameProc <<"  nameFile "<<nameFile <<endl;
//   if(listExpose)     mapIntCls<stringCls> *listExpose ;
	outDebugError<<" EProcType "<<eptProc<<endl;//{Function,Procedure,Label,ProcedureWithExpose};
	outDebugError.flush();
	*/
	ccs.evalSize();
	/*
	outDebugError<<"list of expose "<<endl;
	for(int i1=0;i1<noExpose;i1++)
	  outDebugError<<*(*listExpose)[i1]<<endl;;
  if(noOfArgList)
  { outDebugError<<" list of  arg  in this function is "<<endl;
	 for(i1=0;i1<noOfArgList;i1++) outDebugError<<getArg(i1)<<endl;
  }
  outDebugError<<" **************************"<<endl;
	for( i1=0;i1<ccs.size();i1++)
	  ccs.getPi(i1)->print();

 outDebugError<<"====================================================="<<endl;
	outDebugError.flush();
	*/
 }